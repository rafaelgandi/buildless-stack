const { spawn } = require("child_process");

function onStart(server, options) {
	console.log('[Dialog Plugin] Starting...');
	
	// Show a simple "hello" dialog
	const dialogScript = `display dialog "${options.message ?? 'Hello'}" buttons {"OK"} default button "OK" with icon note`;
	
	const dialogProcess = spawn('osascript', ['-e', dialogScript], {
		stdio: 'inherit'
	});
	
	dialogProcess.on('exit', (code) => {
		console.log(`[Dialog Plugin] Dialog closed with code ${code}`);
	});
	
	dialogProcess.on('error', (err) => {
		console.error('[Dialog Plugin] Dialog error:', err);
	});
}



module.exports = { onStart };
